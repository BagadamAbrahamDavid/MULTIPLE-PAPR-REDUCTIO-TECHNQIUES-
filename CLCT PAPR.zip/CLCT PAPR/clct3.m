%%%%% this is the code for the implementation of New continous companding
%%%%% transform
%%%% this is the code for implementing linear companding
clc;
clear all;
close all;
%------------------
nsym=200;                                                                  % no of symbols
nfft=256;                                                                  % size of fft       
nsub=64;                                                                   % no of sub cariers
a=randint(nsub,nsym);a(a==0)=-1;
b=randint(nsub,nsym);b(b==0)=-1;
sig = a + j*b;  
xt = ifft(sig,nfft);
%*************************************************
%%%% proposed method
% LNST method eqn(3)
u=0.825; A=max(max(xt));
for ii=1:nsub
    Pin=xt(:,ii).^2;
for jj=1:nsym
    if xt(jj,ii)<=Pin(jj)
    y(jj,ii)=(1/u)*xt(jj,ii);
    else
    y(jj,ii)=u*xt(jj,ii);
    end
 end
end
%-----------------------------------------------------
%----------------------------------------------------
u1=2;u2=1;u3=0.45;v1=0.02*(A);v2=0.04*(A);
for ii=1:nsub   
for jj=1:nsym
    if xt(jj,ii)<=v1
    y1(jj,ii)=(u1)*xt(jj,ii);
    else
    if xt(jj,ii)>v1 && xt(jj,ii)<=v2
    y1(jj,ii)=u2*xt(jj,ii);
    else
    if xt(jj,ii)>v2
    y1(jj,ii)=u3*xt(jj,ii);
    end
    end
    end
 end
end
%--------------------------------------
%%% proposed MLCT %--------------------
A=max(max(abs(xt)));
alp=2;beta=0.35;v1=0.3*(A);v2=0.55*(A);
gamma=abs((alp*v1-beta*v2)/(v2-v1));
mu=((v1*v2)/(v2-v1))*(alp-beta);
for ii=1:nsub   
for jj=1:nsym
    if abs(xt(jj,ii))<=v1
    y2(jj,ii)=(alp)*(xt(jj,ii));
    else
    if abs(xt(jj,ii))>v1 && abs(xt(jj,ii))<=v2
    y2(jj,ii)=mu*sign((xt(jj,ii)))-gamma.*(xt(jj,ii));
    else
    if abs(xt(jj,ii))>v2
    y2(jj,ii)=beta*(xt(jj,ii));
    end
    end
    end
 end
end
%----------------------------------
fvtool(xt/-30,1,y/-30,1,y1/-30,2,y2/-30,2);
legend('Original','LNST','ALCT','Proposed',4);
%-------------------------------------

