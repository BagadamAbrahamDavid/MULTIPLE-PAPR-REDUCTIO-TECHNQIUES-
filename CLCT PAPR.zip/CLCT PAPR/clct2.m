%%%% this is the code for implementing linear companding
clc;
clear all;
close all;
%------------------
nsym=200;
nfft=256;
nsub=64;
rx=randint(nsym,nsub,[0 3]);
rxmod=pskmod(rx,4);
xt=ifft(rxmod,nfft);
%*************************************************
%%%% proposed method
% LNST method eqn(3)
E = [1:2:16];          % signal to noise ratio vector in dB   
L1=length(E);   
u=0.625; A=max(max(xt));
for ii=1:nsub
    Pin=exp(A.^2);
    %xt(:,ii).^2;
    
for jj=1:nsym
    if xt(jj,ii)<=Pin
    y(jj,ii)=(1/u)*xt(jj,ii);
    else
    y(jj,ii)=u*xt(jj,ii);
    end
 end
end
%-----------------------------------------------------
%----------------------------------------------------
u1=2;u2=1;u3=0.45;v1=0.02*(A);v2=0.04*(A);
for ii=1:nsub   
for jj=1:nsym
    if xt(jj,ii)<=v1
    y1(jj,ii)=(u1)*xt(jj,ii);
    else
    if xt(jj,ii)>v1 && xt(jj,ii)<=v2
    y1(jj,ii)=u2*xt(jj,ii);
    else
    if xt(jj,ii)>v2
    y1(jj,ii)=u3*xt(jj,ii);
    end
    end
    end
 end
end
%----------------------------------
A=max(max(abs(xt)));
alp=2;beta=0.35;v1=0.3*(A);v2=0.55*(A);
gamma=abs((alp*v1-beta*v2)/(v2-v1));
mu=((v1*v2)/(v2-v1))*(alp-beta);

for ii=1:nsub   
for jj=1:nsym
    if abs(xt(jj,ii))<=v1
    y2(jj,ii)=(alp)*xt(jj,ii);
    else
    if abs(xt(jj,ii))>v1 && abs(xt(jj,ii))<=v2
    y2(jj,ii)=mu*sign(real(xt(jj,ii)))-gamma.*abs(xt(jj,ii));
    else
    if abs(xt(jj,ii))>v2
    y2(jj,ii)=beta*abs(xt(jj,ii));
    end
    end
    end
 end
end
% ---------------------------------
for j=1:length(E)
    kk=.1:0.1:L1*0.1;
    kk=fliplr(kk);
    snr=10^(-E(j)/20);      
  
%--------------------------------------------------
%------------------- passing through the channel
             RxDataIfft  = awgn(xt,(snr-db(std2(xt))));   
             RxDataIfft1 = awgn(y,(snr-db(std2(y))));   
             RxDataIfft2 = awgn(y1,(snr-db(std2(y1)))); 
             RxDataIfft3 = awgn(y2,(snr-db(std2(y2)))); 
%%%%%%%%%%%%%%%%%%%%%%%% End of channel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                    
             Rx =fft(RxDataIfft,nfft);
             RxData=pskdemod(Rx,4); 
             [n1 b1(j)]=biterr(RxData(1:nsym,:),rx);            
             b1(j)=b1(j);
%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Rx1 =fft(RxDataIfft1,nfft);
             RxData1=pskdemod(Rx1,4);
             [n2 b2(j)]=biterr(RxData1(1:nsym,:),rx);
             b2(j)=b2(j);
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
             Rx2 =fft(RxDataIfft2,nfft);
             RxData2=pskdemod(Rx2,4);
             [n3 b3(j)]=biterr(RxData2(1:nsym,:),rx);   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Rx3 =fft(RxDataIfft3,nfft);
             RxData3=pskdemod(Rx3,4); 
             [n4 b4(j)]=biterr(RxData3(1:nsym,:),rx);            
             b4(j)=b4(j);
end
bb1=b4.*kk;
bb2=b3.*kk;
bb3=b2.*kk;
bb4=b1.*kk;


semilogy(E,bb1,'r-');hold on;
semilogy(E,bb2,'k-');hold on;
semilogy(E,bb3,'g-');hold on;
semilogy(E,bb4);hold off;
title('Performance analysis');xlabel('-----EbNo');ylabel('----BER');
legend('No companding','LNST','ALCT','MLCT');
grid on