%%%%% this is the code for the implementation of New continous companding
%%%%% transform
%%%% this is the code for implementing linear companding
clc;
clear all;
close all;
%------------------
nsym=250;                                                                  % no of symbols
nfft=256;                                                                  % size of fft       
nsub=64;                                                                   % no of sub cariers
rx=randint(nsym,nsub);                                                     % generation of data
rxmod=pskmod(rx,4);                                                        % Modulate IQ 
xt=ifft(rxmod,nfft);                                                       % apply ifft eqn(1)
meanSquareValue=sum(xt.*conj(xt),2)/nfft;                                  % calculate the mean value
peakValue = max(xt.*conj(xt),[],2);                                        % calculate the peak value 
paprSymbol = peakValue./meanSquareValue; 
paprSymboldB = 10*log10(paprSymbol);                                       % cal.PAPR eqn(2)
[n P] = hist(paprSymboldB,[0:0.5:18]);
figure,semilogy(P,fliplr(cumsum(n)/nsym),'bx-');hold on;
%*************************************************
%%%% proposed method
% LNST method eqn(3)
u=0.825; A=max(max(xt));
for ii=1:nsub
    Pin=xt(:,ii).^2;
for jj=1:nsym
    if xt(jj,ii)<=Pin(jj)
    y(jj,ii)=(1/u)*xt(jj,ii);
    else
    y(jj,ii)=u*xt(jj,ii);
    end
 end
end
meanSquareValue1=sum(y.*conj(y),2)/nfft;
peakValue1 = max(y.*conj(y),[],2);
paprSymbol1 = peakValue1./meanSquareValue1; 
paprSymboldB1 = 10*log10(paprSymbol1);
[n1 P1] = hist(paprSymboldB1,[0:0.5:18]);
semilogy(P1,fliplr(cumsum(n1)/nsym),'rx-');hold on;
ylim([10^-2 10^0]);grid on;
%-----------------------------------------------------
%----------------------------------------------------
u1=2;u2=1;u3=0.45;v1=0.02*(A);v2=0.04*(A);
for ii=1:nsub   
for jj=1:nsym
    if xt(jj,ii)<=v1
    y1(jj,ii)=(u1)*xt(jj,ii);
    else
    if xt(jj,ii)>v1 && xt(jj,ii)<=v2
    y1(jj,ii)=u2*xt(jj,ii);
    else
    if xt(jj,ii)>v2
    y1(jj,ii)=u3*xt(jj,ii);
    end
    end
    end
 end
end
meanSquareValue2=sum(y1.*conj(y1),2)/nfft;
peakValue2 = max(y1.*conj(y1),[],2);
paprSymbol2 = peakValue2./meanSquareValue2; 
paprSymboldB2 = 10*log10(paprSymbol2);
[n2 P2] = hist(paprSymboldB2,[0:0.5:18]);
semilogy(P2,fliplr(cumsum(n2)/nsym),'kx-');hold on;
% ylim([10^-2 10^0]);grid on;
% legend('Original','LNST','ALCT');
%--------------------------------------
%%% proposed MLCT %--------------------
A=max(max(abs(xt)));
alp=2;beta=0.35;v1=0.3*(A);v2=0.55*(A);
gamma=abs((alp*v1-beta*v2)/(v2-v1));
mu=((v1*v2)/(v2-v1))*(alp-beta);

for ii=1:nsub   
for jj=1:nsym
    if abs(xt(jj,ii))<=v1
    y2(jj,ii)=(alp)*xt(jj,ii);
    else
    if abs(xt(jj,ii))>v1 && abs(xt(jj,ii))<=v2
    y2(jj,ii)=mu*sign(real(xt(jj,ii)))-gamma.*abs(xt(jj,ii));
    else
    if abs(xt(jj,ii))>v2
    y2(jj,ii)=beta*abs(xt(jj,ii));
    end
    end
    end
 end
end
meanSquareValue3=sum(y2.*conj(y2),2)/nfft;
peakValue3 = max(y2.*conj(y2),[],2);
paprSymbol3 = peakValue3./meanSquareValue3; 
paprSymboldB3 = 10*log10(paprSymbol3);
[n3 P3] = hist(paprSymboldB3,[0:0.5:18]);
semilogy(P3,fliplr(cumsum(n3)/nsym),'gx-');hold off;
ylim([10^-2 10^0]);grid on;
legend('Original','LNST','ALCT','Proposed');
