clc;
clear all;
close all;
warning off;
w=0.01:0.1:2*pi;
xin=sin(w);alp=30;xin(xin<0)=0;xin(xin>0)=1;
fs=sum((2*pi)./w);
nfft = 256;                                   % fft size
nSym = 64;                                    % number of symbols
nsub=4;
sig = (randsrc(1,nsub*nSym,[-1 1 ]) + j*randsrc(1,nsub*nSym,[-1 1 ]));  
sig=reshape(sig,nsub,nSym);
sigfft = ifft(sig,nfft);
x=sigfft;
d=[1 2 3];
for dd=1:length(d)
for k=1:nSym
%%%%%%%%%%%%%%%%%%%%%%% exponential %%%%%%%%%%%%%%%%%%%%%
  at=x(:,k).*x(:,k);
  pr=2^1;
  ap=(1-exp(-(x(:,k).*x(:,k))/var(x(:,k)))).^pr/d(dd);
  alpex=(at./ap).^(d(dd)/2);
  xt=x(:,k);
  for i=1:length(x)
      hx(i)=sign(real(xt(i)))*(alpex(i)*(1-exp(-(xt(i)^2)/var(xt))))^pr/d(dd);
      ab(i)=sqrt(-var(xt)*log(1-(xt(i)^d(dd))/alpex(i)));
      invhx(i)=sign(real(xt(i)))*ab(i);
  end   
  invx(:,k)=invhx';
end
meanSquareValue2=sum(invx.*conj(invx),2)/nfft;
peakValue2 = max(invx.*conj(invx),[],2);
paprSymbol2 = peakValue2./meanSquareValue2; 
paprSymboldB2 = 10*log10(paprSymbol2);
[n1 P1] = hist(paprSymboldB2,[0:0.5:25]);
clr={'k','r','g'};
semilogy(P1,fliplr(cumsum(n1)/nSym),clr{dd});
hold on;
end
meanSquareValue2=sum(x.*conj(x),2)/nfft;
peakValue2 = max(x.*conj(x),[],2);
paprSymbol2 = peakValue2./meanSquareValue2; 
paprSymboldB2 = 10*log10(paprSymbol2);
[n1 P1] = hist(paprSymboldB2,[0:0.5:25]);
semilogy(P1,fliplr(cumsum(n1)/nSym));hold off;

grid on;
legend(['with d=',num2str(d(1))],['with d=',num2str(d(2))],['with d=',num2str(d(3))],' No companding',3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ylabel('-------- CCDF');
xlabel('------PAPR(dB)');