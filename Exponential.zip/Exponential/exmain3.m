clc;
warning off;
clear all;
close all;
N=1000;                   %%% length of the subcarriers
Nsym=256;                %% no of symbols
iter=10;                 %% no of iterations
M=16;                    %% for symbol generation and type of modulation
alp=30;
t=0.01:0.1:8.13*pi
w=sum((t));
TrDataBit =abs(round(sin(w./t)));                   %% generate random 200 symols)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E = [0:2:12];          % signal to noise ratio vector in dB   
L1=length(E);
for k=1:iter;
    for j=1:length(E)
            kk=.1:0.1:L1*0.1;
            kk=fliplr(kk);
            snr=round(E(j)+10*log10(2))+3;            
            TrDataMod = qammod(TrDataBit,M);                  %% do IQ modulation 
            x = ifft(TrDataMod,256);                   %% do ifft operation 
            %%%% exponential %%%%%%%%%%%%%%
            d=1.1;
            at=x.*x;
            ap=(1-exp(-(x.*x)/var(x))).^2;
%           id=find(ap==0);ap(id)=0.0001;           
            alpex=(at./ap).^(d/2);
            for i=1:length(x)
             hx(i)   =sign(real(x(i)))*(alpex(i)*(1-exp(-(x(i)^2)/var(x))))^1/d; 
             ab(i)   =sqrt(-var(x)*log(1-(x(i)^d/2)/alpex(i)));
             invhx(i)=sign(real(x(i)))*ab(i);
            end                       
%%%%%%%%%%%%%%%%%%%% End of Transmitter %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             RxDataIfft  = awgn(x,snr-db(std(x)));   
             RxDataIfft2 = awgn(hx,snr-db(std(hx))); 
%%%%%%%%%%%%%%%%%%%%%%%% End of channel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                    
             Rx =fft(RxDataIfft,256);
             RxData=qamdemod(Rx,M); %RxData(RxData>0)=1;
             [n1 b1(k,j)]=biterr(RxData(1:Nsym),TrDataBit);            
             b1(k,j)=b1(k,j)./(j);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
             Rx2 =fft(RxDataIfft2,256);
             RxData2=qamdemod(Rx2,M);% RxData2(RxData2>0)=1;         
             [n3 b3(k,j)]=biterr(RxData2(1:Nsym),TrDataBit);               
    end
end
m1=mean(b1);
m3=mean(b3);
semilogy(E,m1,'rx-');hold on;
semilogy(E,m3,'gx-');hold off;
grid on;
title('Performance analysis');xlabel('-----EbNo');ylabel('----BER');
legend('No companding','Exponential');