%%%% this is code for implementing exponential companding technique for
%%%% PAPR reduction
clc;
clear all;
close all;
warning off;
vrclear; 
alp=30;
nfft = 256;                 % fft size
nSym = 64;                  % number of symbols
sig = (randsrc(1,nSym,[-1 1 ]) + j*randsrc(1,nSym,[-1 1 ]));  
sigfft = ifft(sig,nfft);
x=sigfft;
%%%%%% exponential %%%%%%%%%%%%%%%%%%%%%
d=1;
at=x.*x;
ap=(1-exp(-(x.*x)/var(x))).^2/d;   %% (14)
alpex=(at./ap).^(d/2);
for i=1:length(x)
    hx(i)=sign(real(x(i)))*(alpex(i)*(1-exp(-(x(i)^2)/var(x))))^1/d;     %%(13)
    ab(i)=sqrt(-var(x)*log(1-(x(i)^d)/alpex(i)));
    invhx(i)=sign(real(x(i)))*ab(i);                                     %% (15)
end   
figure,subplot(121);plot(abs(x(:)));title('Before companding')
subplot(122);plot(abs(hx(:)));title('After companding');
%-----------------------------------------------------
fvtool(sigfft/-30,1,hx/-30,2);grid off;
legend('Original','Exponential');
%----------------------------------------------------
%-----------------------------------------------------
clear all;
x=-2:0.5:2;x=x(x~=0);
d=[1 2 3];
at=x.^2;
figure,
for k=1:length(d)
ap=((1-exp(-(x.*x)/var(x)).^2).^1/d(k));                            %% (14)
alpex=(at./ap).^(d(k)/2);
for i=1:length(x)
    hx(i)=(sign(x(i))*(alpex(i)*(1-exp(-x(i)^2/var(x)))))^1/d(k);   %% (13)
end  
xlr={'x--','rx--','kx--'};
plot(x,hx,xlr{k});hold on;
end
legend('d=1','d=2','d=3',4);title('Companding for Exponential companding')
ylim([-3 3]);
xlabel('----------x');
ylabel('---------h(x)');
%-----------------------------------------------
