clc;
clear all;
close all;
warning off;
vrclear; 
nfft = 256;                                                                % fft size
nsym = 256;                                                                % number of symbols
nsub=128;
rx=randint(nsub,nsym);
rxmod=pskmod(rx,4);
x=ifft(rxmod,nfft);
SNR = [0:2:14];                                                            % signal to noise ratio vector in dB   
L1=length(SNR);  
%--------------------------------------------------------------------------
d=2;m=2;a=[1.8  2  2.5  3];
at=abs(x).^2;
ap=(1-exp(-(abs(x).^2)/(2*var(x)))).^(2*m/d);  
for dd=1:length(a)
for i=1:size(x,2)
    alpex=(at(:,i)./ap).^(1/d);
    y=(x(:,i));
    for jj=1:size(x,1)       
        inr=(1-exp(-a(dd)*(y(i)^2)/(2*var(y)))).^m/d;
      hx(jj,i)=(alpex(jj).^2).*(inr);                                     
    end   
end
%--------------------------------------------------------------------------
for j=1:length(SNR)
             kk=.1:0.1:L1*0.1;
             kk=fliplr(kk);
             snr=SNR(j);        
%--------------------------------------------------------------------------
%------------------- passing through the channel --------------------------
             RxDataIfft1 = awgn(hx,(snr-db(std2(hx))));                
%%%%%%%%%%%%%%%%%%%%%%%% End of channel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                    
             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Rx1 =fft(RxDataIfft1,nfft);
             RxData1=pskdemod(Rx1,4);
             [n2 b2(j)]=symerr(RxData1(1:nsub,1:nsym),rx);
             b2(j)=b2(j).*kk(j)./a(dd);               
end
clr={'bx-','rx-','kx-','gx-'};
semilogy(SNR,b2,clr{dd});hold on;
grid on
ylim([10^-3 10^0]);
end
legend('with a=1.8','with a=2','with a=2.5 ','with a=3',3);
xlabel('SNR');
ylabel('---BER');
title('Performance analysis with d=2 & m=2');