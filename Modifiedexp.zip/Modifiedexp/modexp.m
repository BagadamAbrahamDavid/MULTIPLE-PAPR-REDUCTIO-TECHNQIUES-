%%% this the code for the implementation of modified exponential companding
% technique
clc;
clear all;
close all;
warning off;
vrclear; 
nfft = 128;                                                                % fft size
nsym = 64;                                                                 % number of symbols
nsub=64;
rx=randint(nsub,nsym);
rxmod=pskmod(rx,4);
x=ifft(rxmod,nfft);
%----------------------
d=2;m=2;a=[ 2 2.5  3];
at=x.*x;
ap=(1-exp(-(x.*x)/(2*var(x)))).^(2*m/d);  
for dd=1:length(a)
for i=1:size(x,2)
    alpex=(at(:,i)./ap).^(1/d);
    y=x(:,i);
    for j=1:size(x,1)
        inr=(1-exp(-a(dd)*abs(y(i)^2)/(2*var(y)))).^m/d;
    hx(j,i)=alpex(j).*inr;                                     
    end   
end
meanSquareValue2=sum(hx.*conj(hx),2)/nfft;
peakValue2 = max(hx.*conj(hx),[],2);
paprSymbol2 = peakValue2./meanSquareValue2; 
paprSymboldB2 = 10*log10(paprSymbol2);
[n1 P1] = hist(paprSymboldB2,[0:0.5:25]);
clr={'k','r','g'};
semilogy(P1,fliplr(cumsum(n1)/nsym),clr{dd});hold on;
end
grid on;
ylim([10^-2 10^0]);
legend('d=2,a=2,m=2','d=2 m=3 a=2.5','d=2 m=2 a=3');
xlabel('PAPR');
ylabel('CCDF')