%%%% this is the code for implementing linear companding
clc;
clear all;
close all;
%------------------
nsym=250;
nfft=256;
nsub=64;
rx=randint(nsym,nsub);
rxmod=pskmod(rx,4);
xt=ifft(rxmod,nfft);
meanSquareValue=sum(xt.*conj(xt),2)/nfft;
peakValue = max(xt.*conj(xt),[],2);
paprSymbol = peakValue./meanSquareValue; 
paprSymboldB = 10*log10(paprSymbol);
[n P] = hist(paprSymboldB,[0:0.5:18]);
figure,semilogy(P,fliplr(cumsum(n)/nsym),'bx-');hold on;
%*************************************************
%%%% proposed method
% LNST method eqn(3)
u=0.825; A=max(max(xt));
for ii=1:nsub
    Pin=xt(:,ii).^2;
for jj=1:nsym
    if xt(jj,ii)<=Pin(jj)
    y(jj,ii)=(1/u)*xt(jj,ii);
    else
    y(jj,ii)=u*xt(jj,ii);
    end
 end
end
meanSquareValue1=sum(y.*conj(y),2)/nfft;
peakValue1 = max(y.*conj(y),[],2);
paprSymbol1 = peakValue1./meanSquareValue1; 
paprSymboldB1 = 10*log10(paprSymbol1);
[n1 P1] = hist(paprSymboldB1,[0:0.5:18]);
semilogy(P1,fliplr(cumsum(n1)/nsym),'rx-');hold on;
ylim([10^-2 10^0]);grid on;
%-----------------------------------------------------
%----------------------------------------------------
u1=2;u2=1;u3=0.45;v1=0.02*(A);v2=0.04*(A);
for ii=1:nsub   
for jj=1:nsym
    if xt(jj,ii)<=v1
    y1(jj,ii)=(u1)*xt(jj,ii);
    else
    if xt(jj,ii)>v1 && xt(jj,ii)<=v2
    y1(jj,ii)=u2*xt(jj,ii);
    else
    if xt(jj,ii)>v2
    y1(jj,ii)=u3*xt(jj,ii);
    end
    end
    end
 end
end
meanSquareValue2=sum(y1.*conj(y1),2)/nfft;
peakValue2 = max(y1.*conj(y1),[],2);
paprSymbol2 = peakValue2./meanSquareValue2; 
paprSymboldB2 = 10*log10(paprSymbol2);
[n2 P2] = hist(paprSymboldB2,[0:0.5:18]);
semilogy(P2,fliplr(cumsum(n2)/nsym),'kx-');hold off;
ylim([10^-2 10^0]);grid on;
legend('Original','LNST','proposed');
%--------------------------------------

