%%%% this is the code for implementing linear companding
clc;
clear all;
close all;
%------------------
nsym=200;
nfft=256;
nsub=64;
a=randint(nsub,nsym);a(a==0)=-1;
b=randint(nsub,nsym);b(b==0)=-1;
sig = a + j*b;  
xt = ifft(sig,nfft);
%*************************************************
%%%% proposed method
% LNST method eqn(3)
u=0.825; A=max(max(xt));
for ii=1:nsub
    Pin=xt(:,ii).^2;
for jj=1:nsym
    if xt(jj,ii)<=Pin(jj)
    y(jj,ii)=(1/u)*xt(jj,ii);
    else
    y(jj,ii)=u*xt(jj,ii);
    end
 end
end
%-----------------------------------------------------
%----------------------------------------------------
u1=2;u2=1;u3=0.45;v1=0.02*(A);v2=0.04*(A);
for ii=1:nsub   
for jj=1:nsym
    if xt(jj,ii)<=v1
    y1(jj,ii)=(u1)*xt(jj,ii);
    else
    if xt(jj,ii)>v1 && xt(jj,ii)<=v2
    y1(jj,ii)=u2*xt(jj,ii);
    else
    if xt(jj,ii)>v2
    y1(jj,ii)=u3*xt(jj,ii);
    end
    end
    end
 end
end
%--------------------------------------
fvtool(xt/-30,1,y/-30,1,y1/-30,2);
legend('Original','LNST','Proposed',4);
%-------------------------------------
figure,subplot(311),plot(xt(:,end));title('Original symbols');
subplot(312),plot(y(:,end),'r');title('LNST companded');
subplot(313),plot(y1(:,end),'k');title('Proposed method');

