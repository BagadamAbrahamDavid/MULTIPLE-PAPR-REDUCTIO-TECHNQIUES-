%%% this is the file for implementing self companding technique
clc;
clear all;
close all;
warning off;
vrclear; 
nfft = 512;                                                                % fft size
nsym = 600;                                                                 % number of symbols
nsub=256;
rx=randint(nsub,nsym);
rxmod=pskmod(rx,4);
xt=ifft(rxmod,nfft);
meanSquareValue=sum(xt.*conj(xt),2)/nfft;
peakValue = max(xt.*conj(xt),[],2);
paprSymbol = peakValue./meanSquareValue; 
paprSymboldB = 10*log10(paprSymbol);
[n P] = hist(paprSymboldB,[0:0.5:16]);
semilogy(P,fliplr(cumsum(n)/nsym));hold on;

%-------------------------------
b=[0.2  0.6  2 10];a=5;
for ii=1:length(b)
yk=(a.*xt)./(b(ii)+xt);
meanSquareValue2=sum(yk.*conj(yk),2)/nfft;
peakValue2 = max(yk.*conj(yk),[],2);
paprSymbol2 = peakValue2./meanSquareValue2; 
paprSymboldB2 = 10*log10(paprSymbol2);
[n2 P2] = hist(paprSymboldB2,[0:0.5:12]);
clr={'bx-','k','r','g'};
semilogy(P2,fliplr(cumsum(n2)/nsym),clr{ii});hold on;
end
ylim([10^-2 10^0]);
grid on;
legend('Original','With b=0.2','with b=0.6','with b=2','with b=10',3);