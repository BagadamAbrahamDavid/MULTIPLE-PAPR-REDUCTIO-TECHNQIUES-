%%% this is the file for implementing self companding technique
clc;
clear all;
close all;
warning off;
vrclear; 
nfft = 512;                                                                % fft size
nsym = 600;                                                                 % number of symbols
nsub=256;
rx=randint(nsub,nsym);
rxmod=pskmod(rx,4);
x=ifft(rxmod,nfft);
SNR=[1:2:20];
for j=1:length(SNR);
    snr=SNR(j);
    RxDataIfft  = awgn(x,(snr-db(std2(x))));  
    Rx =fft(RxDataIfft,nfft);
    RxData=pskdemod(Rx,4); 
    [n1 b1(j)]=symerr(RxData(1:nsub,1:nsym),rx);          
   
end
semilogy(SNR,b1,'bx-');hold on;
%-------------------------------
b=[0.2 0.5 1];a=5;
for ii=1:length(b)
hx=(a.*x)./(b(ii)+x);
%---------------------
for j=1:length(SNR)
             snr=SNR(j);        
%--------------------------------------------------------------------------
%------------------- passing through the channel --------------------------              
             RxDataIfft1 = awgn(hx,(snr-db(std2(hx))));                
%%%%%%%%%%%%%%%%%%%%%%%% End of channel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Rx1 =fft(RxDataIfft1,nfft);
             RxData1=pskdemod(Rx1,4);
             [n2 b2(j)]=symerr(RxData1(1:nsub,1:nsym),rx);
                            
end
clr={'rx-','kx-','gx-'};
semilogy(SNR,b2,clr{ii});hold on;
grid on;
end
legend('Original','With b=0.1','with b=0.5','with b=5') ;